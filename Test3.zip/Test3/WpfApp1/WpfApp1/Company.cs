﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class Company
    {
        public string Nazev {  get; set; }
        public string? Dic { get; set; }
        public string Obec { get; set; }
        public string? Poznamka {  get; set; }
    }
}
