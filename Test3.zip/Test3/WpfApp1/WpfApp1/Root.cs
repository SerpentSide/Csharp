﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class Root
    {
        public string obchodniJmeno {  get; set; }
        public string dic {  get; set; }
        public Sidlo sidlo { get; set; }

    }
    public class Sidlo
    {
        public string nazevObce {  get; set; }
    }
}
