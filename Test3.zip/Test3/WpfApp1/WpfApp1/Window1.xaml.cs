﻿using Dapper;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interakční logika pro Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1(Root firm)
        {
            InitializeComponent();
            tbDic.Text = firm.dic;
            tbObec.Text = firm.sidlo.nazevObce;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string name = tbName.Text;
            if (!(name.Length > 0))
            {
                erName.Text = "Název je povinný";
                return;
            }
            string dic = tbDic.Text;
            string obec = tbObec.Text;
            if (!(obec.Length > 0))
            {
                erName.Text = "Obec je povinná";
                return;
            }
            string note = tbNote.Text;
            Company c = new Company()
            {
                Nazev = name,
                Dic = dic,
                Obec = obec,
                Poznamka = note
            };
            string _connectionString = "Data Source=company.db";
            SqliteConnection _connection = new SqliteConnection(_connectionString);
            MessageBox.Show("Rows affected: " + _connection.Execute("Insert into Company(Nazev, Dic, Obec, Poznamka) VALUES(@Nazev, @Dic, @Obec, @Poznamka)", c));
            List<Company> company = _connection.Query<Company>("Select * from Company").ToList();
            Window2 w = new Window2(company);
            w.Show();

        }
    }
}
