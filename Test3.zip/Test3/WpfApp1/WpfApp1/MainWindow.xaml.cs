﻿using Dapper;
using Microsoft.Data.Sqlite;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
//https://ares.gov.cz/ekonomicke-subjekty-v-be/rest/ekonomicke-subjekty/61989100
namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            //string _connectionString = "Data Source=company.db";
            //SqliteConnection _connection = new SqliteConnection(_connectionString);
            //_connection.Execute("CREATE TABLE Company (\r\n    Id INTEGER PRIMARY KEY AUTOINCREMENT,\r\n    Nazev TEXT NOT NULL,\r\n    Dic TEXT,\r\n    Obec TEXT NOT NULL,\r\n    Poznamka TEXT\r\n);");

            InitializeComponent();
        }

        private void btnSend_ClickAsync(object sender, RoutedEventArgs e)
        {
            string strIC = tbIC.Text;
            if (!(strIC.Length > 0)) return;
            for (int i = 0; i < strIC.Length; i++) {
                if (strIC[i] > '9' || strIC[i] < '0')
                {
                    tbError.Text = "Jenom čísla";
                    return;
                }
            }
            tbError.Text = "";
            string url = String.Concat("https://ares.gov.cz/ekonomicke-subjekty-v-be/rest/ekonomicke-subjekty/", strIC);
            getIC(url);

            //tbError.Text = url;

        }
        private async Task getIC(string url)
        {
            HttpClient client = new HttpClient();
            var response = await client.GetAsync(url);
            if (!response.IsSuccessStatusCode)
            {
                tbError.Text = response.StatusCode.ToString();
            }
            string jsonString = await response.Content.ReadAsStringAsync();
            Root firm = JsonSerializer.Deserialize<Root>(jsonString);

            Window1 window = new Window1(firm);
            window.Show();

        }

        private void Test_Click(object sender, RoutedEventArgs e)
        {
            string strIC = tbIC.Text;
            if (!(strIC.Length > 0)) return;
            for (int i = 0; i < strIC.Length; i++)
            {
                if (strIC[i] > '9' || strIC[i] < '0')
                {
                    tbError.Text = "Jenom čísla";
                    return;
                }
            }
            tbError.Text = "";
            string url = String.Concat("https://ares.gov.cz/ekonomicke-subjekty-v-be/rest/ekonomicke-subjekty/", strIC);
            getIC(url);

        }
    }
}