using System.Diagnostics;
using System.Xml.Linq;
using Dapper;
using FirstTest.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;

namespace FirstTest.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            using var connection = new SqliteConnection("Data Source=rss.db");
            var rss = connection.Query<Rss>("SELECT * FROM Rss").ToList();
            return View(rss);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            using var connection = new SqliteConnection("DataSource=rss.db");
            var rss = connection.QueryFirstOrDefault<Rss>("Select * from Rss where Id = @Id", new { Id = id });
            return View(rss);
        }
        [HttpPost]
        public IActionResult Edit(Rss rss)
        {
            if (!ModelState.IsValid)
            {
                return View(rss);
            }
            using var connection = new SqliteConnection("Data Source=rss.db");

            connection.Execute(
                @"UPDATE Rss 
          SET Name = @Name,
              Url = @Url,
              Description = @Description,
              Label = @Label
          WHERE Id = @Id",
                rss
            );

            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Create() {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Rss rss)
        {
            if (!ModelState.IsValid)
            {
                return View(rss);
            }
            using var connection = new SqliteConnection("DataSource=rss.db");
            connection.Execute(@"Insert into Rss (Name, Url, Description, Label) values (@Name, @Url, @Description, @Label)", rss);
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id) {
            using var connection = new SqliteConnection("DataSource=rss.db");
            connection.Execute(@"Delete from Rss where Id = @Id", new { Id = id });
            return RedirectToAction("Index");
        }

        public IActionResult Articles()
        {
            using var connection = new SqliteConnection("Data Source=rss.db");
            var rss = connection.Query<Rss>("SELECT * FROM Rss").ToList();
            List<Article> articles = new List<Article>();
            foreach(var source in rss)
            {
                try {
                    var xml = XDocument.Load(source.Url);
                    var items = xml.Descendants("item");
                    foreach (var item in items) {
                        articles.Add(new Article {
                            Title = item.Element("title")?.Value,
                            Description = item.Element("description")?.Value,
                            PubDate = item.Element("pubDate")?.Value
                        });
                    }
                }catch(Exception) { }
            }
        return View(articles);
        }
    }
}
