﻿using Microsoft.AspNetCore.Mvc;

namespace FirstTest.Controllers
{
    public class RssController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
