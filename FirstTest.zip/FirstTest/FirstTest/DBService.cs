﻿
using Dapper;
using FirstTest.Models;
using Microsoft.Data.Sqlite;
namespace FirstTest
{
    public class DBService
    {
        private readonly string _connection;
        public DBService(IConfiguration configuration)
        {
            _connection = configuration.GetConnectionString("DefaultConnection");
        }
        public IEnumerable<Rss> GetAll()
        {
            using var connection = new SqliteConnection(_connection);
            return connection.Query<Rss>("Select * from Rss");
        }
    }
}


