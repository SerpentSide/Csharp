﻿using System.ComponentModel.DataAnnotations;

namespace FirstTest.Models
{
    public class Rss
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Název je povinný")]
        [MaxLength(200)]
        public string Name { get; set; }
        [Required(ErrorMessage = "Url je povinné")]
        [RegularExpression(@"^https:\/\/[a-zA-Z\.]+.*$", ErrorMessage = "Neplatná URL")]
        public string Url { get; set; }
        [MaxLength(1000)]
        public string? Description { get; set; }
        [Required(ErrorMessage = "Štítek je povinný")]
        public string Label { get; set; }
    }
}
