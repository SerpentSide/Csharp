﻿using System.ComponentModel;

namespace WpfApp
{
    public class Subjekt : INotifyPropertyChanged
    {
        private string? _name;
        private int? _ico;
        private string? _date;
        public string? Name
        {
            get => _name;
            set
            {
                _name = value;
                OnPropertyChanged(nameof(Name));
            }
        }
        public int? Ico
        {
            get => _ico;
            set
            {
                _ico = value;
                OnPropertyChanged(nameof(Ico));
            }
        }
        public string? Date
        {
            get => _date;
            set
            {
                _date = value;
                OnPropertyChanged(nameof(Date));
            }
        }
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string name)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}