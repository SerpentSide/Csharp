﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string selected = cBCity.SelectedItem?.ToString() ?? string.Empty;
            string sel = (cBCity.SelectedItem as ComboBoxItem)?.Content.ToString();
            if (selected != string.Empty)
            {
                getCity(sel);
            }
        }

        public async Task getCity(string city)
        {
            List<Subjekt> subs = new List<Subjekt>();
            city = city.ToLower().Trim();
            string url = $"https://dataor.justice.cz/api/file/zp-full-{city}-2024.xml";
            XDocument doc = XDocument.Load(url);
            foreach (var item in doc.Descendants("Subjekt"))
            {
                Subjekt s = new Subjekt()
                {
                    Name = item.Element("nazev")?.Value,
                    Ico = int.Parse(item.Element("ico")?.Value),
                    Date = item.Element("zapisDatum")?.Value
                };
                subs.Add(s);
            }
            dgSubjekt.ItemsSource = subs;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            Subjekt item = button?.DataContext as Subjekt;
            if (item != null) {
                Window1 w = new Window1(item);
                w.Show();
            }
        }
    }
}