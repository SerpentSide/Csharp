﻿
namespace Test2.Models
{

    public class Root
    {
        public Dictionary<string, Currency> kurzy { get; set; }
    }
    public class Currency
    {
        public float dev_stred {  get; set; }
    }
}
