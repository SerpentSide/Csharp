﻿using System.ComponentModel.DataAnnotations;

namespace Test2.Models
{
    public class Form
    {
        [Required(ErrorMessage = "Musíš zadat jméno")]
        public string Name { get; set; }
        public string? Email { get; set; }
        [Required(ErrorMessage = "Musíš zadat měnu")]
        public float Currency {  get; set; }
        [Required(ErrorMessage = "Musíš zadat hodnotu")]
        public float Value { get; set; }
    }
}
