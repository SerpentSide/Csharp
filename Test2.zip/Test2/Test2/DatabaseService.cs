﻿using Dapper;
using Microsoft.Data.Sqlite;
using Test2.Models;

namespace Test2
{
    public class DatabaseService
    {
        private string _connectionString = "Data Source=exchange.db";
        private SqliteConnection _connection;
        public DatabaseService() {
            _connection = new SqliteConnection(_connectionString);
        }
        public int InsertForm(Form form) {
            int num = _connection.Execute("Insert into Exchange(Name, Email, Currency, Value) VALUES (@Name, @Email, @Currency, @Value)", form);
            return num;
        }
        public List<Form> GetFormList() {
        return _connection.Query<Form>("Select * from Exchange").ToList();
        }
    }
}
