using System.Diagnostics;
using System.Text.Json;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.Sqlite;
using Test2.Models;
using static System.Net.WebRequestMethods;

namespace Test2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private DatabaseService _databaseService;

        public HomeController(ILogger<HomeController> logger, DatabaseService db)
        {
            _logger = logger;
            _databaseService = db;
        }

        [HttpGet]
        public IActionResult Index()
        {
            HttpClient client = new HttpClient();
            string url = "https://data.kurzy.cz/json/meny/b[1].json";
            string jsonString = client.GetStringAsync(url).Result;
            //Console.WriteLine(jsonString);
            Root kurzy = JsonSerializer.Deserialize<Root>(jsonString);
            foreach (var item in kurzy.kurzy) {
                //Console.WriteLine($"{item.Key} {item.Value.dev_stred}");
            }
            ViewBag.Root = kurzy;
            return View(new Form());
        }
        [HttpPost]
        public IActionResult Index(Form form)
        {
            Console.WriteLine($"{form.Name}, {form.Value * form.Currency}");
            HttpClient client = new HttpClient();
            string url = "https://data.kurzy.cz/json/meny/b[1].json";
            string jsonString = client.GetStringAsync(url).Result;
            Root kurzy = JsonSerializer.Deserialize<Root>(jsonString);
            ViewBag.Root = kurzy;
            foreach (var error in ModelState)
            {
                foreach (var e in error.Value.Errors)
                {
                    Console.WriteLine($"{error.Key}: {e.ErrorMessage}");
                }
            }
            if (!ModelState.IsValid) {
                Console.WriteLine("Invalid Model");
                return View(new Form());
            }
            Console.WriteLine("Valid model");
            Console.WriteLine("Rows affected" + _databaseService.InsertForm(form));
            //return View(new Form());
            return RedirectToAction("Exchanges");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Exchanges() {

        return View(_databaseService.GetFormList());
        }
    }
}
