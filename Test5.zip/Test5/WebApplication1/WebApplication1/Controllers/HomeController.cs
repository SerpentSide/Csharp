using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly DataStorageService _dataStorageService;
        private readonly GetUradService _getUradService;

        public HomeController(ILogger<HomeController> logger, DataStorageService ds, GetUradService gu)
        {
            _logger = logger;
            _dataStorageService = ds;
            _getUradService = gu;
        }

        public IActionResult Index()
        {
            List<Polozka> pos = _getUradService.GetPolozkas();

            return View(pos);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            Form model = new Form() { Id = id };
            return View(model);
        }
        [HttpPost]
        public IActionResult Edit(Form form)
        {
            if (!ModelState.IsValid)
            {
                return RedirectToAction("Index");
            }
            _dataStorageService.Save(form, "soubor.txt");
            return RedirectToAction("Index");
        }
    }
}
