﻿using System.Xml.Linq;
using WebApplication1.Models;

namespace WebApplication1
{
    public class GetUradService
    {

        public List<Polozka> GetPolozkas() {
            string url = "https://apl2.czso.cz/iSMS/do_cis_export?kodcis=46&typdat=0&cisjaz=203&format=0";
            XDocument doc = XDocument.Load(url);
            List<Polozka> pol = new List<Polozka>();
            foreach(var item in doc.Descendants("POLOZKA"))
            {
                Polozka po = new Polozka()
                {
                    chodnota = item.Element("CHODNOTA")?.Value,
                    text = item.Element("TEXT")?.Value
                };
                pol.Add(po);
            }
            return pol;
        }
    }
}
