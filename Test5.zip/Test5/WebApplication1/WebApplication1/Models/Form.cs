﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Form
    {
        public int Id { get; set; }
        [Required(ErrorMessage="Jméno je povinné")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Email je povinný")]
        [RegularExpression(@"^[a-z1-9]+@[a-z1-9]+.[a-z1-9]+$")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Pohlaví je povinné")]
        public string Gender { get; set; }
        [Required(ErrorMessage = "Poznámka je povinná")]
        [MaxLength(500)]
        public string Note { get; set; }
    }
}
