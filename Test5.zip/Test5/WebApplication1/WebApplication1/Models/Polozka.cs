﻿namespace WebApplication1.Models
{
    public class Polozka
    {
        public string chodnota { get; set; }
        public string text { get; set; }
    }
}
